"""
Classes:
1. Snake
2. Ladder
3. Board
4. Player
"""

