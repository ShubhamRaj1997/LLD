class BoardConstants(object):
    BOARD_SIZE = 100
    BOARD_START = 1
    BOARD_END = BOARD_SIZE