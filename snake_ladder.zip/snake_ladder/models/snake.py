from snake_ladder.models.props import Prop


class Snake(Prop):
    def __init__(self):
        super(Snake, self).__init__()


class Ladder(Prop):
    def __init__(self):
        super(Ladder, self).__init__()
